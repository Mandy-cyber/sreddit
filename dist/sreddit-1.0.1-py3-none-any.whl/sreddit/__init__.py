from sreddit.srtitles import SubRedditTitles
from sreddit.srbodies import SubRedditBodies