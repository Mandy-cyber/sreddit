from srtitles import SubRedditTitles
from srbodies import SubRedditBodies